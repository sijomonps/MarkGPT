/* ChatGPT Bookmarker - content.js (optimized runtime) */
(() => {
  if (window.__bkmrk_loaded) return;
  window.__bkmrk_loaded = true;

  let enabled = true;
  let allBookmarks = [];
  let savedMsgKeys = new Set();
  let savedMsgIds = new Set();
  let savedMsgSigs = new Set();

  let toastEl = null;
  let panel = null;
  let panelOpen = false;
  let activeMessageSelector = "";
  let panelCountEl = null;
  let panelListEl = null;
  let panelResizeObserver = null;
  let inlineObserver = null;
  let inlineSyncTick = 0;
  let inlineFullSyncNeeded = false;
  const pendingInlineMessages = new Set();
  const inlineRows = new WeakMap();
  const inlineButtons = new WeakMap();

  const MESSAGE_SELECTORS = [
    "[data-message-author-role]",
    "article[data-testid]",
    "article",
    "[data-testid^='conversation-turn']",
    "[data-message-id]"
  ];

  const BM = 'd="M19 21l-7-4-7 4V5a2 2 0 012-2h10a2 2 0 012 2z"';
  const svg = (s, f) =>
    '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="' + (f ? "currentColor" : "none") + '" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path ' + BM + "/></svg>";
  const IC_OUT = svg(16, 0);
  const IC_FILL = svg(16, 1);
  const IC_SM = svg(11, 1);
  const IC_X =
    '<svg width="9" height="9" viewBox="0 0 10 10" fill="none"><path d="M1.5 1.5l7 7M8.5 1.5l-7 7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>';

  const css = document.createElement("style");
  css.id = "bkmrk-css";
  css.textContent = [
    ".bk-inline-row{display:flex;justify-content:flex-end;width:100%;margin-top:6px}",
    ".bk-inline-btn{width:24px;height:24px;border-radius:6px;border:none;background:transparent;color:rgba(255,255,255,.52);cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0;transition:background .12s,color .12s}",
    ".bk-inline-btn:hover{background:rgba(255,255,255,.08);color:rgba(255,255,255,.86)}",
    ".bk-inline-btn.on{color:#fff}",
    "#bk-t{position:fixed;bottom:28px;left:50%;transform:translateX(-50%) translateY(8px);background:#2f2f2f;color:#e0e0e0;font:500 12px/1 system-ui,sans-serif;padding:10px 20px;border-radius:22px;border:1px solid rgba(255,255,255,.08);box-shadow:0 4px 20px rgba(0,0,0,.5);opacity:0;pointer-events:none;z-index:2147483647;transition:opacity .2s,transform .2s;white-space:nowrap}",
    "#bk-t.on{opacity:1;transform:translateX(-50%) translateY(0)}",
    "#bk-p{position:fixed;top:72px;left:10px;z-index:2147483640;font:13px/1.4 system-ui,sans-serif;display:flex;flex-direction:column;align-items:flex-start;gap:4px}",
    "#bk-tog{display:flex;align-items:center;gap:5px;padding:5px 10px;background:rgba(38,38,38,.92);border:1px solid rgba(255,255,255,.15);border-radius:20px;cursor:pointer;color:rgba(255,255,255,.65);user-select:none;box-shadow:0 2px 8px rgba(0,0,0,.35);transition:background .15s,border-color .15s}",
    "#bk-tog:hover{background:rgba(60,60,60,.98);border-color:rgba(255,255,255,.3);color:#fff}",
    "#bk-tog-n{font-size:11px;font-weight:600}",
    "#bk-list{width:210px;background:#1e1e1e;border:1px solid rgba(255,255,255,.1);border-radius:10px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,.5);display:none}",
    "#bk-list.open{display:block}",
    "#bk-list-inner{max-height:320px;overflow-y:auto;padding:4px}",
    "#bk-list-inner::-webkit-scrollbar{width:3px}",
    "#bk-list-inner::-webkit-scrollbar-thumb{background:rgba(255,255,255,.1);border-radius:3px}",
    ".bk-li{display:flex;align-items:center;gap:6px;padding:6px 8px;border-radius:7px;cursor:pointer;transition:background .12s}",
    ".bk-li:hover{background:rgba(255,255,255,.07)}",
    ".bk-li-ic{flex-shrink:0;color:rgba(255,255,255,.3)}",
    ".bk-li-lbl{flex:1;min-width:0;font-size:12px;color:#d0d0d0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:500}",
    ".bk-li-del{flex-shrink:0;width:16px;height:16px;border:none;background:transparent;color:#555;cursor:pointer;display:flex;align-items:center;justify-content:center;border-radius:3px;padding:0;opacity:0;transition:opacity .12s}",
    ".bk-li:hover .bk-li-del{opacity:1}",
    ".bk-li-del:hover{background:rgba(255,255,255,.08);color:#ccc}",
    ".bk-em{padding:12px 8px;text-align:center;color:#4a4a4a;font-size:11px}",
    "#bk-wm{padding:5px 8px 6px;text-align:center;font-size:9px;color:rgba(255,255,255,.45);letter-spacing:.4px;border-top:1px solid rgba(255,255,255,.12);user-select:none}"
  ].join("\n");
  document.head.appendChild(css);

  chrome.storage.local.get(["extensionEnabled", "bookmarks", "bkmrk_scrollTo"], (r) => {
    enabled = r.extensionEnabled !== false;
    allBookmarks = r.bookmarks || [];
    rebuildBookmarkIndex();
    if (enabled) {
      boot();
      const target = normalizeScrollTarget(r.bkmrk_scrollTo);
      if (target && targetMatchesCurrentChat(target)) {
        retryScroll(target, true);
      }
    }
  });

  chrome.storage.onChanged.addListener((ch) => {
    if (ch.extensionEnabled) {
      enabled = ch.extensionEnabled.newValue !== false;
      if (enabled) showAll();
      else hideAll();
    }

    if (ch.bookmarks) {
      allBookmarks = ch.bookmarks.newValue || [];
      rebuildBookmarkIndex();
      if (enabled) {
        syncInlineButtons();
        renderPanel();
      }
    }

    if (ch.bkmrk_scrollTo && enabled) {
      const target = normalizeScrollTarget(ch.bkmrk_scrollTo.newValue);
      if (target && targetMatchesCurrentChat(target)) retryScroll(target, true);
    }
  });

  function boot() {
    mkToast();
    mkPanel();
    startInlineButtons();
  }

  function showAll() {
    if (!toastEl) boot();
    if (panel) panel.style.display = "";
    startInlineButtons();
  }

  function hideAll() {
    stopInlineButtons();
    removeInlineButtons();
    if (panel) panel.style.display = "none";
  }

  function mkToast() {
    if (toastEl) return;
    toastEl = document.createElement("div");
    toastEl.id = "bk-t";
    document.documentElement.appendChild(toastEl);
  }

  function flash(m) {
    if (!toastEl) return;
    toastEl.textContent = m;
    toastEl.classList.add("on");
    clearTimeout(toastEl._t);
    toastEl._t = setTimeout(() => toastEl.classList.remove("on"), 2200);
  }

  function mkPanel() {
    if (panel) return;
    panel = document.createElement("div");
    panel.id = "bk-p";
    panel.innerHTML =
      '<div id="bk-tog">' + IC_SM + '<span id="bk-tog-n">0</span></div>' +
      '<div id="bk-list"><div id="bk-list-inner"></div><div id="bk-wm">MarkGPT by Sijomon P S</div></div>';

    document.documentElement.appendChild(panel);
    panelCountEl = panel.querySelector("#bk-tog-n");
    panelListEl = panel.querySelector("#bk-list-inner");
    posPanel();

    panel.querySelector("#bk-tog").addEventListener("click", () => {
      panelOpen = !panelOpen;
      panel.querySelector("#bk-list").classList.toggle("open", panelOpen);
    });

    renderPanel();

    if (window.ResizeObserver && !panelResizeObserver) {
      panelResizeObserver = new ResizeObserver(schedulePanelPos);
      panelResizeObserver.observe(document.querySelector("nav") || document.body);
    }
    window.addEventListener("resize", schedulePanelPos, { passive: true });
  }

  function posPanel() {
    if (!panel) return;
    const nav = document.querySelector("nav");
    const offset = nav ? Math.round(nav.getBoundingClientRect().right) + 10 : 10;
    panel.style.left = offset + "px";
  }

  function schedulePanelPos() {
    requestAnimationFrame(posPanel);
  }

  function renderPanel() {
    if (!panel || !panelCountEl || !panelListEl) return;

    panelCountEl.textContent = String(allBookmarks.length);

    if (!allBookmarks.length) {
      panelListEl.innerHTML = '<div class="bk-em">No bookmarks yet</div>';
      return;
    }

    panelListEl.innerHTML = "";
    const frag = document.createDocumentFragment();
    const reversed = [...allBookmarks].reverse();

    reversed.forEach((bm, i) => {
      const ri = allBookmarks.length - 1 - i;
      const row = document.createElement("div");
      row.className = "bk-li";
      row.innerHTML =
        '<span class="bk-li-ic">' + IC_SM + "</span>" +
        '<span class="bk-li-lbl">' + esc(bm.label) + "</span>" +
        '<button class="bk-li-del" title="Remove">' + IC_X + "</button>";

      row.addEventListener("click", () => goTo(bm));
      row.querySelector(".bk-li-del").addEventListener("click", (e) => {
        e.stopPropagation();
        allBookmarks.splice(ri, 1);
        chrome.storage.local.set({ bookmarks: allBookmarks });
      });
      frag.appendChild(row);
    });

    panelListEl.appendChild(frag);
  }

  function startInlineButtons() {
    if (inlineObserver) {
      syncInlineButtons();
      return;
    }
    inlineFullSyncNeeded = true;
    scheduleInlineButtonsSync();
    inlineObserver = new MutationObserver((mutations) => {
      queueInlineUpdates(mutations);
      scheduleInlineButtonsSync();
    });
    inlineObserver.observe(document.body, { childList: true, subtree: true });
  }

  function stopInlineButtons() {
    if (inlineObserver) {
      inlineObserver.disconnect();
      inlineObserver = null;
    }
    pendingInlineMessages.clear();
    inlineFullSyncNeeded = false;
    if (inlineSyncTick) {
      cancelAnimationFrame(inlineSyncTick);
      inlineSyncTick = 0;
    }
  }

  function queueInlineUpdates(mutations) {
    if (!mutations || !mutations.length) return;
    for (let i = 0; i < mutations.length; i += 1) {
      const mut = mutations[i];
      if (!mut || mut.type !== "childList") continue;

      const target = mut.target;
      if (target instanceof Element) {
        collectMessageFromNode(target);
      }

      if (mut.addedNodes && mut.addedNodes.length) {
        for (let j = 0; j < mut.addedNodes.length; j += 1) {
          collectMessageFromNode(mut.addedNodes[j]);
        }
      }

      if (mut.removedNodes && mut.removedNodes.length) {
        inlineFullSyncNeeded = true;
      }
    }
  }

  function collectMessageFromNode(node) {
    if (!(node instanceof Element)) return;
    if (node.classList && node.classList.contains("bk-inline-row")) return;
    if (node.closest && node.closest(".bk-inline-row")) return;

    const direct = findMessageFromNode(node);
    if (direct) pendingInlineMessages.add(direct);

    if (!activeMessageSelector) getMessages();
    const selector = activeMessageSelector || MESSAGE_SELECTORS[0];

    if (node.matches && node.matches(selector)) pendingInlineMessages.add(node);
    const nested = node.querySelectorAll(selector);
    for (let i = 0; i < nested.length; i += 1) {
      pendingInlineMessages.add(nested[i]);
    }
  }

  function scheduleInlineButtonsSync() {
    if (inlineSyncTick) return;
    inlineSyncTick = requestAnimationFrame(() => {
      inlineSyncTick = 0;
      if (!enabled) return;
      if (inlineFullSyncNeeded || !pendingInlineMessages.size) {
        syncInlineButtons();
      } else {
        pendingInlineMessages.forEach((messageEl) => ensureInlineButton(messageEl));
      }
      pendingInlineMessages.clear();
      inlineFullSyncNeeded = false;
    });
  }

  function syncInlineButtons() {
    const messages = getMessages();
    for (let i = 0; i < messages.length; i += 1) {
      ensureInlineButton(messages[i]);
    }
  }

  function ensureInlineButton(messageEl) {
    if (!messageEl || !messageEl.parentElement) return;

    let row = inlineRows.get(messageEl);
    if (!row || !row.isConnected) {
      row = document.createElement("div");
      row.className = "bk-inline-row";
      const btn = document.createElement("button");
      btn.className = "bk-inline-btn";
      btn.type = "button";
      btn.title = "Bookmark this message";
      btn.innerHTML = IC_OUT;

      btn.addEventListener("mousedown", (e) => e.stopPropagation());
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (isSaved(messageEl)) {
          flash("Already bookmarked");
          return;
        }
        doSave(messageEl);
      });

      row.appendChild(btn);
      messageEl.insertAdjacentElement("beforeend", row);
      inlineRows.set(messageEl, row);
      inlineButtons.set(messageEl, btn);
    } else if (messageEl.lastElementChild !== row) {
      messageEl.insertAdjacentElement("beforeend", row);
    }

    updateInlineButtonState(messageEl);
  }

  function updateInlineButtonState(messageEl) {
    const row = inlineRows.get(messageEl);
    if (!row || !row.isConnected) return;
    const btn = inlineButtons.get(messageEl) || row.querySelector(".bk-inline-btn");
    if (!btn) return;
    if (!inlineButtons.has(messageEl)) inlineButtons.set(messageEl, btn);
    const saved = isSaved(messageEl);
    btn.innerHTML = saved ? IC_FILL : IC_OUT;
    btn.classList.toggle("on", saved);
  }

  function removeInlineButtons() {
    const rows = document.querySelectorAll(".bk-inline-row");
    rows.forEach((row) => row.remove());
  }

  function findMessageFromNode(node) {
    if (activeMessageSelector) {
      const known = node.closest(activeMessageSelector);
      if (known) return known;
    }
    for (const s of MESSAGE_SELECTORS) {
      const found = node.closest(s);
      if (found) {
        activeMessageSelector = s;
        return found;
      }
    }
    return null;
  }

  function getMessages() {
    if (activeMessageSelector) {
      const known = document.querySelectorAll(activeMessageSelector);
      if (known.length) return known;
    }
    for (const s of MESSAGE_SELECTORS) {
      const found = document.querySelectorAll(s);
      if (found.length) {
        activeMessageSelector = s;
        return found;
      }
    }
    return [];
  }

  function normalizeText(s) {
    return String(s || "").replace(/\s+/g, " ").trim();
  }

  function messageSnippet(el) {
    return fullMessageText(el).substring(0, 300);
  }

  function snippetKey(s) {
    return normalizeText(s).substring(0, 140);
  }

  function snippetTail(s) {
    return normalizeText(s).slice(-140);
  }

  function fullMessageText(el) {
    return normalizeText((el && (el.textContent || el.innerText)) || "");
  }

  function buildSignatureToken(msgKey, msgTail, msgLen) {
    if (!msgKey) return "";
    const len = Number(msgLen) || 0;
    return msgKey + "|" + (msgTail || "") + "|" + len;
  }

  function rebuildBookmarkIndex() {
    savedMsgKeys = new Set();
    savedMsgIds = new Set();
    savedMsgSigs = new Set();
    for (const bm of allBookmarks) {
      const k = bm.msgKey || snippetKey((bm.textSnippet || "").substring(0, 300));
      if (k.length > 20) savedMsgKeys.add(k);
      if (bm.messageId) savedMsgIds.add(String(bm.messageId));
      const sig = buildSignatureToken(
        bm.msgKey || k,
        bm.msgTail || snippetTail((bm.textSnippet || "").substring(0, 300)),
        bm.msgLen || 0
      );
      if (sig) savedMsgSigs.add(sig);
    }
  }

  function isSaved(el) {
    const msgId = extractMessageId(el);
    if (msgId && savedMsgIds.has(msgId)) return true;
    const text = fullMessageText(el);
    const key = snippetKey(text);
    const sig = buildSignatureToken(key, snippetTail(text), text.length);
    if (sig && savedMsgSigs.has(sig)) return true;
    return key.length > 20 && savedMsgKeys.has(key);
  }

  function doSave(el) {
    const label = (prompt("Bookmark label:") || "").trim();
    if (!label) return;

    const fullText = fullMessageText(el);
    const textSnippet = fullText.substring(0, 300);
    const msgKey = snippetKey(fullText);
    const msgTail = snippetTail(fullText);
    const msgLen = fullText.length;
    const messageId = extractMessageId(el);
    const turnIndex = getMessageIndex(el);

    allBookmarks.push({
      label,
      textSnippet,
      url: location.href,
      savedAt: Date.now(),
      msgKey,
      msgTail,
      msgLen,
      messageId,
      turnIndex
    });

    chrome.storage.local.set({ bookmarks: allBookmarks }, () => {
      rebuildBookmarkIndex();
      syncInlineButtons();
      flash("Saved: " + label);
    });
  }

  function esc(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function basePath(u) {
    try {
      const p = new URL(u);
      return p.origin + p.pathname;
    } catch {
      return u;
    }
  }

  function goTo(bm) {
    const target = {
      url: bm.url || "",
      textSnippet: bm.textSnippet || "",
      msgKey: bm.msgKey || snippetKey((bm.textSnippet || "").substring(0, 300)),
      msgTail: bm.msgTail || snippetTail((bm.textSnippet || "").substring(0, 300)),
      msgLen: bm.msgLen || normalizeText(bm.textSnippet || "").length,
      messageId: bm.messageId || "",
      turnIndex: Number.isFinite(bm.turnIndex) ? bm.turnIndex : -1
    };
    if (basePath(location.href) === basePath(bm.url || "")) retryScroll(target, false);
    else if (bm.url) chrome.storage.local.set({ bkmrk_scrollTo: target }, () => (location.href = bm.url));
  }

  function scrollMsg(targetInput, options) {
    const target = normalizeScrollTarget(targetInput);
    const suppressNotFoundToast = options && options.suppressNotFoundToast;
    if (!target) return false;

    const byId = findMessageById(target.messageId);
    if (byId) {
      highlightMessage(byId);
      return true;
    }

    const indexed = findMessageByTurnIndex(target.turnIndex);
    if (indexed) {
      const idxText = fullMessageText(indexed);
      const idxScore = scoreMessageMatch(target, idxText);
      if (idxScore >= 0.7) {
        highlightMessage(indexed);
        return true;
      }
    }

    if (target.msgKey) {
      for (const m of getMessages()) {
        const text = fullMessageText(m);
        const k = snippetKey(text);
        if (k !== target.msgKey) continue;
        const wantLen = Number(target.msgLen) || 0;
        const wantTail = target.msgTail || "";
        const exactBySignature = wantLen > 0 && wantTail
          ? text.length === wantLen && snippetTail(text) === wantTail
          : true;
        if (exactBySignature) {
          highlightMessage(m);
          return true;
        }
      }
    }

    if (!target.textSnippet) return false;
    const best = findBestMessageMatch(target);
    if (best && best.score >= 0.5) {
      highlightMessage(best.el);
      return true;
    }
    const q = snippetKey(target.textSnippet).substring(0, 100);
    if (q) {
      for (const m of getMessages()) {
        if (normalizeText(m.textContent || m.innerText).includes(q)) {
          highlightMessage(m);
          return true;
        }
      }
    }
    if (!suppressNotFoundToast) flash("Message not found in this chat");
    return false;
  }

  function retryScroll(targetInput, removeStorageOnSuccess) {
    const target = normalizeScrollTarget(targetInput);
    if (!target) return;
    let n = 0;
    const iv = setInterval(() => {
      if (scrollMsg(target, { suppressNotFoundToast: true })) {
        if (removeStorageOnSuccess) chrome.storage.local.remove("bkmrk_scrollTo");
        clearInterval(iv);
        return;
      }
      n += 1;
      if (n % 3 === 0) nudgeScrollSearch(n);
      if (n > 36) {
        clearInterval(iv);
        flash("Message not found in this chat");
      }
    }, 800);
  }

  function nudgeScrollSearch(step) {
    const scroller = getChatScroller();
    if (!scroller) return;
    if (step === 3 && scroller.scrollTop > 0) {
      scroller.scrollTop = 0;
      return;
    }
    const delta = Math.max(Math.floor(scroller.clientHeight * 0.9), 500);
    if (step <= 18) scroller.scrollTop = Math.max(0, scroller.scrollTop - delta);
    else scroller.scrollTop = Math.min(scroller.scrollHeight, scroller.scrollTop + delta);
  }

  function getChatScroller() {
    const firstMessage = getMessages()[0];
    let node = firstMessage || document.querySelector("main") || document.body;
    while (node && node !== document.body) {
      if (node instanceof HTMLElement) {
        const style = getComputedStyle(node);
        const canScroll = /(auto|scroll)/.test(style.overflowY) && node.scrollHeight > node.clientHeight + 10;
        if (canScroll) return node;
      }
      node = node.parentElement;
    }
    return document.scrollingElement || document.documentElement;
  }

  function extractMessageId(el) {
    if (!el || !(el instanceof Element)) return "";
    const direct = el.getAttribute("data-message-id") || "";
    if (direct) return direct;
    const nested = el.querySelector("[data-message-id]");
    return (nested && nested.getAttribute("data-message-id")) || "";
  }

  function escapeForSelectorValue(value) {
    if (window.CSS && typeof window.CSS.escape === "function") return window.CSS.escape(String(value));
    return String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  }

  function findMessageById(messageId) {
    if (!messageId) return null;
    const attrValue = escapeForSelectorValue(messageId);
    const byDataId = document.querySelector('[data-message-id="' + attrValue + '"]');
    if (byDataId) return findMessageFromNode(byDataId) || byDataId.closest("article") || byDataId;
    const byDomId = document.getElementById(messageId);
    if (byDomId) return findMessageFromNode(byDomId) || byDomId.closest("article") || byDomId;
    return null;
  }

  function highlightMessage(el) {
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    el.style.outline = "2px solid rgba(255,255,255,.2)";
    el.style.borderRadius = "8px";
    el.style.transition = "outline .3s";
    setTimeout(() => (el.style.outline = ""), 2500);
  }

  function normalizeScrollTarget(target) {
    if (!target) return null;
    if (typeof target === "string") return { textSnippet: target };
    if (typeof target === "object") return target;
    return null;
  }

  function getMessageIndex(el) {
    const messages = getMessages();
    for (let i = 0; i < messages.length; i += 1) {
      if (messages[i] === el) return i;
    }
    return -1;
  }

  function findMessageByTurnIndex(turnIndex) {
    if (!Number.isFinite(turnIndex) || turnIndex < 0) return null;
    const messages = getMessages();
    if (!messages.length) return null;
    if (turnIndex < messages.length) return messages[turnIndex];
    return messages[messages.length - 1];
  }

  function overlapScore(a, b) {
    if (!a || !b) return 0;
    const aTokens = new Set(a.split(" ").filter(Boolean));
    const bTokens = new Set(b.split(" ").filter(Boolean));
    if (!aTokens.size || !bTokens.size) return 0;
    let hit = 0;
    aTokens.forEach((t) => {
      if (bTokens.has(t)) hit += 1;
    });
    return hit / Math.max(aTokens.size, bTokens.size);
  }

  function scoreMessageMatch(target, text) {
    const key = target.msgKey || "";
    const tail = target.msgTail || "";
    const len = Number(target.msgLen) || 0;
    const currentKey = snippetKey(text);
    const currentTail = snippetTail(text);
    let score = 0;
    if (key && currentKey === key) score += 0.5;
    if (tail && currentTail === tail) score += 0.3;
    if (len > 0) {
      const diff = Math.abs(text.length - len);
      if (diff <= 6) score += 0.2;
      else if (diff <= 18) score += 0.1;
    }
    if (target.textSnippet) {
      const base = normalizeText(target.textSnippet).substring(0, 240);
      const textCut = text.substring(0, 240);
      score += overlapScore(base, textCut) * 0.2;
    }
    return Math.min(score, 1);
  }

  function findBestMessageMatch(target) {
    let bestEl = null;
    let bestScore = 0;
    const messages = getMessages();
    for (let i = 0; i < messages.length; i += 1) {
      const m = messages[i];
      const text = fullMessageText(m);
      const score = scoreMessageMatch(target, text);
      if (score > bestScore) {
        bestScore = score;
        bestEl = m;
      }
    }
    return bestEl ? { el: bestEl, score: bestScore } : null;
  }

  function targetMatchesCurrentChat(targetInput) {
    const target = normalizeScrollTarget(targetInput);
    if (!target || !target.url) return true;
    return basePath(location.href) === basePath(target.url);
  }
})();
